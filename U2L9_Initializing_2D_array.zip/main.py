a1 = [2, 7, 6]
a2 = [9, 5, 1]
a3 = [4, 3, 8]
Magic3 = [a1, a2, a3] # an array of arrays

def IzM(arr):
  h = 0
  v = 0
  d = 0
  
# Horizontals
  for x in range (len(arr)):
    L1 = arr[x]
    for i in range (len(L1)):
      V1 = L1[i]
      h = h + V1
  h = float(h/3)
  
  
# Verticals
  for x in range (len(arr)):
    vert1 = arr[0][x]
    v = v + vert1
  for x in range (len(arr)):
    vert2 = arr[1][x]
    v = v + vert2
  for x in range (len(arr)):
    vert3 = arr[2][x]
    v = v + vert3
  v = float(v/3)  
  
# Diagnols
  for x in range (len(arr)):
    diag1 = arr[x][x]
    d = d + diag1  
  for x in range (len(arr)):
    diag2 = arr[2-x][x]
    d = d + diag2 
  d = float(d/2)
  
  m = float(h + v + d)/3
  print("Horizontals add to:",h,"\nVerticals add to:",v,"\nDiagnols add to:",d)
  
  if h == v and h == d and v == d:
    print("It is a magic square!")
    
  return m


print("The magic number for a 3 by 3 magic square is:", IzM(Magic3))

 
