me = "Muntasir"
print("Hello", me)