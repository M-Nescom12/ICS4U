num = input("Please input a whole number: ") 
num = int(num) 

x = input("Pleae input a whole number. Use any whole number except zero: ")
x = int(x)

num2 = num / x

print("When", num, " is divided by", x, "the result is:", num2)