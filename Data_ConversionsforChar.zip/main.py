def toLower(x):
  x = ord(x)
  if 96 < x < 123:
    print("Error: Not an uppercase letter")  
    print(" ")
  else:
    x = x + 32
    return chr(x)
while True: 
  user = input("Input 'Y'to play or 'N' to quit...")
  user = str(user)
  if user == 'N' or user == 'n':
    break
  else:
    x = input("Please input an uppercase letter:")
    x = str(x)
    if toLower(x) != None:
      print("The lowercase of that letter is:", toLower(x))
