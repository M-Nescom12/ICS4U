amount = 8
amount = amount + 1



print(24)
print("The amount is: ", amount)

amount = (amount - 1) * 2
print(amount)

amount = amount/2

print(amount)